source('r3js.r')

obj <- r3js_new()

N <- 250
x <- rnorm(N, 0.5, 0.2)
y <- rnorm(N, 0.5, 0.2)
z <- rnorm(N, 0.5, 0.2)

obj <- r3js_add(obj, r3js_point(x, y, z))

y <- seq(0, 1, 0.005)
x <- cos(y*50) / 2 + 0.5
z <- sin(y*50) / 2 + 0.5

obj <- r3js_add(obj, r3js_line(x, y, z))

r3js_gen(obj)
