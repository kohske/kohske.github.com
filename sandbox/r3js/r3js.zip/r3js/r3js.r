
r3js_point <- function(x, y, z) {
  list(type = "point", n = length(x), x = x, y = y, z = z)
}

r3js_line <- function(x, y, z) {
  list(type = "line", n = length(x), x = x, y = y, z = z)
}

r3js_tojson <- function(obj) {
  sprintf("var r3jsdata = %s;", toJSON(obj))
}

r3js_add <- function(obj, value) {
  obj$values <- c(obj$values, list(value))
  obj
}

r3js_new <- function(xlim = c(0, 1), ylim = c(0, 1), zlim = c(0, 1), values = NULL) {
  list(xlim = xlim, ylim = ylim, values = values)
}

r3js_gen <- function(obj, name = "r3js", dir = tempdir(), browse = TRUE) {
  dir.create(dir)
  
  file.copy("Three.js", dir, TRUE)
  file.copy("LICENSE.Three.js", dir, TRUE)
  
  sf <- file("r3js.html", "r")
  src <- readLines(sf)
  close(sf)
  
  jf <- file("r3js.js", "r")
  js <- readLines(jf)
  close(jf)
  
  src <- sub("%data%",  paste(r3js_tojson(obj), collapse = "\n"), src)
  src <- sub("%js%", paste(js, collapse = "\n"), src)

  ofp <- sprintf("%s/%s.html", dir, name)
  of <- file(ofp, "w")
  writeLines(src, of)
  close(of)

  if (browse) browseURL(paste("file:///", normalizePath(ofp), sep = ""))
}
